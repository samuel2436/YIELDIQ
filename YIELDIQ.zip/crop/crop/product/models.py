from django.db import models

# Create your models here.

class Product(models.Model):
    product_id = models.AutoField(primary_key=True)
    type = models.CharField(max_length=45)
    name = models.CharField(max_length=45)
    image = models.CharField(max_length=100)
    quantity = models.FloatField()
    price = models.CharField(max_length=45)
    farmer_id = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'product'




