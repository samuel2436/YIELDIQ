from django.conf.urls import url, include
from product import views

urlpatterns = [

    url('add_product/',views.add_product),
    url('view_product',views.view_procuct),
    url('vw_ord',views.view_prodct2)
]