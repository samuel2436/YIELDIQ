from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
from product.models import Product
from user.models import User
# Create your views here.

def add_product(request):
    ss=request.session["uid"]
    if request.method == 'POST':
        obj=Product()
        obj.type=request.POST.get('product_type')
        obj.name=request.POST.get('product_name')
        # obj.image=request.POST.get('pimg')
        myfile = request.FILES[ 'pimg' ]
        fs = FileSystemStorage()
        filename =fs.save(myfile.name, myfile)
        obj.image=myfile.name
        obj.quantity=request.POST.get('quantity')
        obj.price=request.POST.get('price')
        obj.farmer_id=ss
        obj.save()
    return render(request,'product/product add(2).html')

def view_procuct(request):
    obj = Product.objects.all()
    context = {
        'f': obj
    }
    return render(request,'product/product view(4).html',context)

def view_prodct2(request):
    obj = Product.objects.all()
    context = {
        'g': obj
    }
    return render(request,'product/View product(6).html',context)