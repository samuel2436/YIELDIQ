from django.conf.urls import url
from predict import views
from django.urls import path
from .views import calculate_min_max
urlpatterns=[
    url('predict/',views.predict),
    url('pred/',views.calculate_min_max),
    path('pred/', calculate_min_max, name='calculate_min_max')

]