from django.db import models
from order.models import Order
# Create your models here.

class Payment(models.Model):
    payment_id = models.AutoField(primary_key=True)
    method = models.CharField(max_length=45)
    cashholder_name = models.CharField(max_length=45)
    cvv = models.CharField(max_length=45)
    amount = models.CharField(max_length=45)
    #order_id = models.IntegerField(blank=True, null=True)
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    status = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'payment'



