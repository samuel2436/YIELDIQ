from django.http import HttpResponseRedirect
from django.shortcuts import render
from payment.models import Payment
from order.models import Order
from user.models import User
from product.models import Product

# Create your views here.



def payment(request,idd):
    obb=Order.objects.get(order_id=idd)
    context={
        'a':obb
    }
    if request.method == 'POST':
        obj = Payment()
        obj.cashholder_name = request.POST.get('holder_name')
        obj.method = request.POST.get('method')
        obj.cvv = request.POST.get('cvv')
        obj.amount = request.POST.get('amount')
        obj.order_id = idd
        obj.status="paid"
        obj.save()
        obb=Order.objects.get(order_id=idd)
        obb.status="paid"
        obb.save()
    return render(request, 'payment/payment(3).html',context)


def payment_view(request):
    obj = Payment.objects.all()
    context = {
        'e': obj
    }
    return render(request, 'payment/Payment view(4).html', context)

def payment_viewad(request):
    obj = Payment.objects.all()
    context = {
        'w': obj
    }
    return render(request, 'payment/Payment view admin.html', context)




def addre(request):
    ss = request.session["uid"]
    obj = Payment.objects.filter(order__user_id=ss)
    context = {
        'e': obj
    }
    return render(request, 'payment/uservw_pay.html', context)