from django.conf.urls import url, include
from payment import views

urlpatterns = [
    url('payment/(?P<idd>\w+)',views.payment),
    url('payment_view/',views.payment_view),
    url('rev/',views.addre),
    url('paymntad',views.payment_viewad)

]