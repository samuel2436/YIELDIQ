from django.db import models

# Create your models here.

class Farmer(models.Model):
    farmer_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=45)
    type = models.CharField(max_length=45)
    experience = models.CharField(max_length=45)
    contact_no = models.CharField(max_length=45)
    email = models.CharField(max_length=45)
    status = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'farmer'
