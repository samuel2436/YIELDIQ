from django.shortcuts import render
from farmer.models import Farmer
from login.models import LogIn
# Create your views here.

def reg_farmer(request):
    if request.method=='POST':
        obj=Farmer()
        obj.name=request.POST.get('name')
        obj.type=request.POST.get('type_of_farmer')
        obj.experience=request.POST.get('experience')
        obj.contact_no=request.POST.get('contact')
        obj.email=request.POST.get('email')
        obj.status="Pending"
        obj.save()
        from django.http import HttpResponseRedirect

        obb = LogIn()
        obb.username=obj.email
        obb.password=request.POST.get('password')
        obb.type = "farmer"
        obb.u_id = obj.farmer_id
        obb.save()
        return HttpResponseRedirect('/temp/home')
    return render(request,'farmer/reg farmer(1).html')


def manage_farmer(request):
    obj=Farmer.objects.all()
    context={
        'a':obj
    }
    return render(request,'farmer/manage farmer(2).html',context)

def view_farmer(request):
    if request.method=="POST":
        vv=request.POST.get('search')
        obj=Farmer.objects.filter(name__icontains=vv,status='Approve')
        context={
            'b':obj
        }
        return render(request,'farmer/Farmer View(5).html',context)
    else:
        obj = Farmer.objects.filter(status='Approve')
        context = {
            'b': obj
        }
        return render(request,'farmer/Farmer View(5).html',context)


def approve(request,idd):
        obb = Farmer.objects.get(farmer_id=idd)
        obb.status = "Approve"
        obb.save()
        return manage_farmer(request)

def reject(request,idd):
    obb = Farmer.objects.get(farmer_id=idd)
    obb.status="Rejected"
    obb.save()
    return manage_farmer(request)

def block(request,idd):
    obb=Farmer.objects.get(farmer_id=idd)
    obb.status="Blocked"
    obb.save()
    return manage_farmer(request)