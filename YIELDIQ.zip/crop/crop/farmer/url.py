from django.conf.urls import url,include
from farmer import views

urlpatterns=[
    url('reg_farmer/',views.reg_farmer),
    url('manage_farmer/',views.manage_farmer),
    url('view_farmer/',views.view_farmer),
    url('approve/(?P<idd>\w+)',views.approve),
    url('reject/(?P<idd>\w+)',views.reject),
    url('block/(?P<idd>\w+)',views.block)
]