from django.http import HttpResponseRedirect
from django.shortcuts import render
from user.models import User
from login.models import LogIn
from temp import  views
# Create your views here.

def regusr(request):
    if request.method == 'POST':
        obj=User()
        obj.name=request.POST.get('name')
        obj.email=request.POST.get('email')
        obj.contact_no=request.POST.get('contact_number')
        obj.save()


        obb = LogIn()
        obb.username = obj.email
        obb.password = request.POST.get('password')
        obb.type = "user"
        obb.u_id = obj.user_id
        obb.save()
        return HttpResponseRedirect('/temp/home')
    return render(request,'user/reusr(1).html')

def user_view(request):
    if request.method=="POST":
        vv=request.POST.get('search')
        obj = User.objects.filter(name__icontains=vv)
        context = {
            'm': obj
        }
        return render(request, 'user/User View (3).html', context)
    else:
        obj = User.objects.all()
        context = {
            'm': obj
        }
        return render(request,'user/User View (3).html',context)