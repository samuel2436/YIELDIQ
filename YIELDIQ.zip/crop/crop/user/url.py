from django.conf.urls import url, include
from user import views

urlpatterns = [
    url('regusr/',views.regusr),
    url('user_view',views.user_view)

]