from django.conf.urls import url, include
from login import views

urlpatterns = [

    url('login/',views.login)

]