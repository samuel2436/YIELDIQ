from django.http import HttpResponseRedirect
from django.shortcuts import render
from login.models import LogIn


def login(request):
    if request.method == "POST":
        eml = request.POST.get("unm")
        password = request.POST.get("pswd")
        obj = LogIn.objects.filter(username=eml, password=password)
        print(len(obj))
        tp = ""
        for ob in obj:
            tp = ob.type
            uid = ob.u_id
            if tp == "farmer":
                request.session["uid"] = uid
                return HttpResponseRedirect('/temp/farmer')
            elif tp == "user":
                request.session["uid"] = uid
                return HttpResponseRedirect('/temp/user/')
            elif tp == "admin":
                request.session["uid"] = uid
                return HttpResponseRedirect('/temp/admin/')
        else:
            objlist = "username or password incorrect.....please try again....!"
            context = {
                'msg': objlist,
            }
            return render(request, 'login/login(1).html', context)
    return render(request,'login/login(1).html')


