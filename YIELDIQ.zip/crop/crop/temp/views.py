from django.shortcuts import render

# Create your views here.
def admin(request):
    return render(request,'temp/admin.html')

def farmer(request):
    return render(request,'temp/Farmer.html')

def user(request):
    return render(request,'temp/User.html')

def home(request):
    return render(request,'temp/home.html')
