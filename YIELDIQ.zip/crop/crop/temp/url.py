from django.conf.urls import url, include
from temp import views

urlpatterns = [
    url('home/',views.home),
    url('admin/', views.admin),
    url('farmer/', views.farmer),
    url('user/', views.user),
]