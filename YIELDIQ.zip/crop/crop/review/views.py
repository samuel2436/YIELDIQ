from django.shortcuts import render
from review.models import Review
from payment.models import Payment
from user.models import User
# Create your views here.

def comment(request,idd):
    obb=Payment.objects.get(payment_id=idd)
    context={
        's':obb
    }
    if request.method == 'POST':
        obj=Review()
        obj.rating=request.POST.get('rating')
        obj.comment=request.POST.get('comment')
        obj.payment_id=idd
        obj.save()
    return render(request,'review/comment(4).html',context)

def comment_act(request):
    obj = Review.objects.all()
    context = {
        'h': obj
    }
    return render(request,'review/Comment action view(5).html',context)

def comment_view(request):
    obj = Review.objects.all()
    context = {
        'j': obj
    }
    return render(request,'review/Comment View(6).html',context)

def solve(request):
    obj = Review.objects.all()
    context = {
        'k': obj
    }
    return render(request,'review/Comment View by farmer(5).html',context)

def sol(request,idd):
    obb=Review.objects.get(review_id=idd)
    obb.action="Solved"
    obb.save()
    return solve(request)

def unsol(request,idd):
    obb=Review.objects.get(review_id=idd)
    obb.action="Not Solved"
    obb.save()
    return solve(request)
