from django.db import models
from user.models import User
from payment.models import Payment
# Create your models here.


class Review(models.Model):
    review_id = models.AutoField(primary_key=True)
    rating = models.CharField(max_length=45)
    comment = models.CharField(max_length=45, blank=True, null=True)
    # payment_id = models.IntegerField(blank=True, null=True)
    payment=models.ForeignKey(Payment,on_delete=models.CASCADE)
    action = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'review'

