from django.conf.urls import url, include
from review import views

urlpatterns = [

    url('comment/(?P<idd>\w+)',views.comment),
    url('comment_act/',views.comment_act),
    url('comment_view',views.comment_view),
    url('comment_solve',views.solve),
    url('solved/(?P<idd>\w+)', views.sol),
    url('unslvd/(?P<idd>\w+)', views.unsol),

]