from django.shortcuts import render
from about.models import About


# Create your views here.
def addabout(request):
    if request.method == 'POST':
        obj=About()
        obj.office=request.POST.get('office')
        obj.officer=request.POST.get('officer')
        obj.address=request.POST.get('address')
        obj.phone=request.POST.get('phone')
        obj.url=request.POST.get('url')
        obj.save()

    return render(request,'about/about add.html')


def aboutu(request):
    obj = About.objects.all()
    context = {
        's': obj
    }
    return render(request, 'about/officeview.html',context)


def aboutf(request):
    obj = About.objects.all()
    context = {
        't': obj
    }
    return render(request, 'about/view office_farmer.html',context)