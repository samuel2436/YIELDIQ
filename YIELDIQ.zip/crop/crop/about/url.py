from django.conf.urls import url, include
from about import views
urlpatterns = [

    url('add_about/',views.addabout),
    url('aboutf',views.aboutf),
    url('aboutu',views.aboutu)
]