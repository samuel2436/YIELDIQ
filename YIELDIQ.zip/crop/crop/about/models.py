from django.db import models

class About(models.Model):
    about_id = models.AutoField(primary_key=True)
    office = models.CharField(max_length=45)
    officer = models.CharField(max_length=45)
    address = models.CharField(max_length=45)
    phone = models.CharField(max_length=45)
    url = models.CharField(max_length=500)

    class Meta:
        managed = False
        db_table = 'about'


