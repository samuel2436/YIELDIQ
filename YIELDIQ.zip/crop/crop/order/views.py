from django.http import HttpResponseRedirect
from django.shortcuts import render
from order.models import Order
from product.models import Product
from user.models import User
# Create your views here.
def manage_order(request):
    obj = Order.objects.all()
    context = {
        'c': obj
    }
    return render(request,'order/manage order(3).html',context)

def order(request,idd):
    ss=request.session["uid"]
    obb=Product.objects.get(product_id=idd)
    context={
        'a':obb
    }
    if request.method == 'POST':
        obj=Order()
        obj.product_id=idd
        obj.user_id=ss
        hh=int(obj.product.price)
        obj.quantity=request.POST.get('quantity')
        kk=int(obj.quantity)
        obj.amount=hh*kk
        obj.status="Pending"
        obj.save()

        obk=Product.objects.get(product_id=idd)
        obk.quantity=int(obk.quantity)-int(obj.quantity)
        obk.save()
        return HttpResponseRedirect('/order/pay/')
    return render(request,'order/order(7).html',context)


def acc(request,idd):
    obb=Order.objects.get(order_id=idd)
    obb.status="Approved"
    obb.save()
    return manage_order(request)

def rej(request,idd):
    obb=Order.objects.get(order_id=idd)
    obb.status="Rejected"
    obb.save()
    return manage_order(request)

def pay(request):
    ss=request.session["uid"]
    obj = Order.objects.filter(status="Approved",user_id=ss)
    context = {
        'd': obj
    }
    return render(request,'order/pay(2).html', context)

def cancel(request,idd):
    obb=Order.objects.get(order_id=idd)
    obb.status="Cancelled"
    obb.save()
    return HttpResponseRedirect('/order/pay/')
