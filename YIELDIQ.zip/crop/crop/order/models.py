from django.db import models
from product.models import  Product
from user.models import User
# Create your models here.

class Order(models.Model):
    order_id = models.AutoField(primary_key=True)
    # product_id = models.IntegerField(blank=True, null=True)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    amount = models.CharField(max_length=45)
    # user_id = models.IntegerField(blank=True, null=True)
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    quantity = models.FloatField()
    status = models.CharField(max_length=45)


    class Meta:
        managed = False
        db_table = 'order'
