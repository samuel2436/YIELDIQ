from django.conf.urls import url, include
from order import views

urlpatterns = [

    url('manage',views.manage_order),
    url('order/(?P<idd>\w+)',views.order),
    url('approve/(?P<idd>\w+)',views.acc),
    url('reject/(?P<idd>\w+)', views.rej),
    url('pay/', views.pay),
    url('can/(?P<idd>\w+)',views.cancel)

]